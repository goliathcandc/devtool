-- MySQL dump 10.13  Distrib 5.6.43, for Linux (x86_64)
--
-- Host: localhost    Database: devtool_databas
-- ------------------------------------------------------
-- Server version	5.6.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wt_alexa`
--

DROP TABLE IF EXISTS `wt_alexa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_alexa` (
  `Domain` varchar(90) NOT NULL,
  `Added` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `linksin` int(10) unsigned NOT NULL,
  `review_count` int(10) unsigned NOT NULL,
  `review_avg` float NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `country_code` varchar(2) NOT NULL,
  `country_name` varchar(100) NOT NULL,
  `country_rank` int(10) unsigned NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_alexa`
--

LOCK TABLES `wt_alexa` WRITE;
/*!40000 ALTER TABLE `wt_alexa` DISABLE KEYS */;
INSERT INTO `wt_alexa` (`Domain`, `Added`, `Modified`, `linksin`, `review_count`, `review_avg`, `rank`, `country_code`, `country_name`, `country_rank`) VALUES ('pageinsider.com','2016-03-08 08:01:01','2016-03-08 13:01:01',0,0,0,61089,'IN','India',26126),('mysticalramnaam.com','2016-03-12 04:02:13','2016-03-12 09:02:13',0,0,0,0,'','',0),('freetool.info','2016-03-12 04:03:35','2016-04-12 23:30:38',0,0,0,9381393,'','',0),('waytosocial.com','2016-03-17 16:01:04','2016-03-17 20:01:04',0,0,0,660113,'RU','Russia',56065),('jhow.com','2016-03-26 18:59:26','2016-03-26 22:59:26',0,0,0,379818,'TR','Turkey',8795),('filejar.io','2016-03-26 23:43:20','2016-03-27 03:43:20',0,0,0,0,'','',0),('www.freetool.info','2016-03-27 11:41:15','2016-03-27 15:41:15',0,0,0,0,'','',0),('houseofprophets.com','2016-03-27 15:43:40','2016-03-27 19:43:40',0,0,0,0,'','',0),('kingdomcampus.com','2016-03-27 15:43:56','2016-03-27 19:43:56',0,0,0,0,'','',0),('ganeshasouvenir.com','2016-03-27 15:57:37','2016-03-27 19:57:37',0,0,0,15512729,'','',0),('a-host.net','2016-03-27 16:39:11','2016-03-27 20:39:11',0,0,0,0,'','',0),('hostingservant.com','2016-03-27 16:40:09','2016-03-27 20:40:09',0,0,0,3193437,'','',0),('www.fiverr.com','2016-03-28 09:31:47','2016-03-28 13:31:47',0,0,0,486,'IN','India',177),('www.healthtttips.blogspot.com','2016-03-28 09:33:51','2016-03-28 13:33:51',0,0,0,2143835,'PK','Pakistan',16592),('byeqima.com','2016-04-18 11:39:57','2016-04-18 15:39:57',0,0,0,1392621,'','',0),('cools4u.com','2016-04-24 15:37:37','2016-04-24 19:37:37',0,0,0,586066,'','',0),('google.com','2018-09-05 06:44:54','2018-09-26 10:15:23',0,0,0,1,'US','United States',1),('www.furniture.co.nz','2018-09-18 11:13:20','2018-09-18 11:13:20',0,0,0,1257952,'NZ','New Zealand',5460),('theappleherald.com','2018-11-24 03:07:05','2018-11-24 03:07:05',0,0,0,0,'','',0),('seostrategicpartner.com','2018-11-25 11:58:18','2018-11-25 11:58:18',0,0,0,0,'','',0),('inglare.com','2018-12-22 15:55:33','2018-12-22 15:55:33',0,0,0,0,'','',0),('twitter.com','2018-12-22 15:55:48','2018-12-22 15:55:49',0,0,0,12,'US','United States',8),('p2e.be','2019-01-09 14:59:10','2019-01-09 14:59:10',0,0,0,0,'','',0),('webdesignaction.fr','2019-01-09 14:59:45','2019-01-09 14:59:45',0,0,0,0,'','',0),('wowbabycare.com','2019-01-16 18:26:01','2019-01-16 18:26:01',0,0,0,0,'','',0),('norahnova.com','2019-01-17 00:24:16','2019-01-17 00:24:16',0,0,0,16750414,'','',0),('matkaplay.net','2019-01-26 19:08:09','2019-01-26 19:08:09',0,0,0,1454016,'IN','India',71235),('sattamatka.mobi','2019-01-26 19:08:34','2019-01-26 19:08:34',0,0,0,34558,'IN','India',2435),('hindityping.com','2019-01-27 05:36:43','2019-01-27 05:36:43',0,0,0,1796339,'IN','India',152341),('bitmagazine.pw','2019-01-30 19:44:44','2019-02-11 13:15:07',0,0,0,0,'','',0),('wowfashiontrend.com','2019-02-10 10:05:51','2019-02-10 10:05:51',0,0,0,0,'','',0),('www.twohippieshemp.com','2019-02-20 10:55:37','2019-02-20 10:55:37',0,0,0,0,'','',0),('baidu.com','2019-02-23 05:04:46','2019-02-23 05:04:46',0,0,0,4,'CN','China',1),('www.goliathcandc.com','2019-02-24 18:22:52','2019-02-24 18:22:52',0,0,0,0,'','',0),('www.fsbwa.com','2019-02-24 18:23:25','2019-02-24 18:23:25',0,0,0,805993,'US','United States',160877);
/*!40000 ALTER TABLE `wt_alexa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wt_backlinks`
--

DROP TABLE IF EXISTS `wt_backlinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_backlinks` (
  `Domain` varchar(90) NOT NULL,
  `Added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Cnt` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_backlinks`
--

LOCK TABLES `wt_backlinks` WRITE;
/*!40000 ALTER TABLE `wt_backlinks` DISABLE KEYS */;
INSERT INTO `wt_backlinks` (`Domain`, `Added`, `Modified`, `Cnt`) VALUES ('pageinsider.com','2016-03-08 13:03:35','2016-03-08 13:03:35',227000),('selfiesbabe.com','2016-03-25 02:04:45','2016-03-25 02:04:45',552),('petfriendlyspain.com','2016-03-27 17:46:33','2016-03-27 17:46:33',357),('houseofprophets.com','2016-03-27 19:44:17','2016-03-27 19:44:17',555),('kingdomcampus.com','2016-03-27 19:44:38','2016-03-27 19:44:38',106),('smallseotools.com','2016-04-12 03:53:48','2016-04-12 03:53:48',56200),('videoweb.ca','2016-04-12 23:14:37','2016-04-12 23:14:37',47),('berlaz.ca','2016-04-12 23:16:51','2016-04-12 23:16:51',55),('berlazweb.ca','2016-04-12 23:17:37','2016-04-12 23:17:37',69),('www.furniture.co.nz','2018-09-18 11:17:37','2018-09-18 11:17:37',49700),('sugarluxx.com','2018-10-15 16:31:29','2018-10-15 16:31:29',169),('theappleherald.com','2018-11-24 03:08:21','2018-11-24 03:08:21',6),('corpdot.com','2018-11-24 03:08:43','2018-11-24 03:08:43',101),('sattamatkai.co','2019-01-26 19:07:27','2019-01-26 19:07:27',924),('matkaplay.net','2019-01-26 19:07:46','2019-01-26 19:07:46',16100),('bitmagazine.pw','2019-01-30 19:47:52','2019-02-11 13:16:07',58),('www.fashiontrend.com','2019-02-10 10:07:28','2019-02-10 10:07:28',119),('www.wowfashiontrend.com','2019-02-10 10:08:02','2019-02-10 10:08:02',5),('webtargetedtraffic.com','2019-02-10 23:21:17','2019-02-10 23:21:17',8910),('memonpropertypoint.com','2019-02-15 23:14:31','2019-02-15 23:14:32',63),('www.twohippieshemp.com','2019-02-20 10:54:08','2019-02-20 10:54:08',4),('www.fsbwa.com','2019-02-21 18:36:30','2019-02-21 18:36:30',1650),('www.goliathcandc.com','2019-02-21 18:37:04','2019-02-24 18:19:15',1);
/*!40000 ALTER TABLE `wt_backlinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wt_catalog`
--

DROP TABLE IF EXISTS `wt_catalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_catalog` (
  `Domain` varchar(90) NOT NULL,
  `Added` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dmoz` int(10) unsigned NOT NULL,
  `yandex` int(10) unsigned NOT NULL,
  `yahoo` int(10) unsigned NOT NULL,
  `alexa` int(10) unsigned NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_catalog`
--

LOCK TABLES `wt_catalog` WRITE;
/*!40000 ALTER TABLE `wt_catalog` DISABLE KEYS */;
INSERT INTO `wt_catalog` (`Domain`, `Added`, `Modified`, `dmoz`, `yandex`, `yahoo`, `alexa`) VALUES ('turnkey-shop.com','2016-03-08 02:41:53','2016-04-16 23:35:54',0,0,0,1),('pageinsider.com','2016-03-08 08:02:18','2016-03-08 13:02:18',0,127,0,1),('selfiesbabe.com','2016-03-24 22:00:55','2016-03-25 02:00:55',0,8,0,0),('drivingtaxi.com','2016-03-24 22:01:30','2016-03-25 02:01:30',0,8,0,1),('www.healthtttips.blogspot.com','2016-03-28 09:36:46','2016-03-28 13:36:46',0,0,0,1),('videoweb.ca','2016-04-12 19:20:14','2016-04-12 23:20:14',0,0,0,0),('findanysite.com','2016-04-29 13:09:20','2016-04-29 17:09:20',0,0,0,1),('www.furniture.co.nz','2018-09-18 11:15:51','2018-09-18 11:15:51',0,0,0,1),('calibration.airflite.com.au','2019-01-25 05:41:40','2019-01-25 05:41:40',0,0,0,1),('bitmagazine.pw','2019-01-30 19:50:18','2019-01-30 19:50:18',0,0,0,0),('memonpropertypoint.com','2019-02-15 23:17:16','2019-02-15 23:17:16',0,0,0,0),('baidu.com','2019-02-23 05:05:23','2019-02-23 05:05:23',0,0,0,1),('webtargetedtraffic.com','2019-02-24 15:52:36','2019-02-24 15:52:36',0,0,0,1);
/*!40000 ALTER TABLE `wt_catalog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wt_diagnostic`
--

DROP TABLE IF EXISTS `wt_diagnostic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_diagnostic` (
  `Domain` varchar(90) NOT NULL,
  `Added` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `google` enum('safe','warning','caution','untested') NOT NULL,
  `mcafee` enum('safe','warning','caution','untested') NOT NULL,
  `norton` enum('safe','warning','caution','untested') NOT NULL,
  `avg` enum('safe','warning','caution','untested') NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_diagnostic`
--

LOCK TABLES `wt_diagnostic` WRITE;
/*!40000 ALTER TABLE `wt_diagnostic` DISABLE KEYS */;
INSERT INTO `wt_diagnostic` (`Domain`, `Added`, `Modified`, `google`, `mcafee`, `norton`, `avg`) VALUES ('pageinsider.com','2016-03-08 08:02:45','2016-03-08 13:02:45','caution','untested','safe','untested'),('www.mailinum.com','2016-03-19 17:39:12','2016-03-19 21:39:12','caution','untested','untested','untested'),('selfiesbabe.com','2016-03-24 22:03:13','2016-03-25 02:03:13','caution','untested','untested','untested'),('forexlanka.com','2016-03-27 06:04:46','2016-03-27 10:04:46','caution','untested','untested','untested'),('a-host.net','2016-03-27 16:41:42','2016-03-27 20:41:42','caution','untested','safe','untested'),('denbeconsulting.com','2016-03-27 20:41:48','2016-03-28 00:41:48','caution','untested','safe','untested'),('www.healthtttips.blogspot.com','2016-03-28 09:38:20','2016-03-28 13:38:20','caution','untested','safe','untested'),('videoweb.ca','2016-04-12 19:21:26','2016-04-12 23:21:26','caution','untested','untested','untested'),('jacadis.com','2016-04-21 21:30:02','2016-04-22 01:30:02','caution','untested','untested','untested'),('joshuadwilliams.com','2016-04-21 21:31:44','2016-04-22 01:31:44','caution','untested','safe','untested'),('infotecindia.com','2016-04-26 02:25:39','2016-04-26 06:25:39','caution','untested','untested','untested'),('firstppt.com','2016-04-27 15:22:47','2016-04-27 19:22:47','caution','untested','untested','untested'),('rtradersprofessional.com','2018-09-02 11:39:15','2018-09-02 11:39:15','caution','untested','untested','untested'),('articlespinner.com','2018-09-12 05:00:04','2018-09-12 05:00:04','caution','untested','warning','untested'),('turbospinner.com','2018-09-12 05:03:22','2018-09-12 05:03:22','caution','untested','untested','untested'),('www.furniture.co.nz','2018-09-18 11:16:22','2018-09-18 11:16:22','caution','untested','safe','untested'),('jeeprally.com','2018-10-22 19:12:18','2018-10-22 19:12:18','caution','untested','safe','untested'),('cnn.com','2018-10-25 23:38:58','2018-10-25 23:38:58','caution','untested','safe','untested'),('theappleherald.com','2018-11-24 03:07:36','2018-11-24 03:07:36','caution','untested','untested','untested'),('seostrategicpartner.com','2018-11-25 11:58:43','2018-11-25 11:58:43','caution','untested','untested','untested'),('computerplanet.net','2018-12-18 04:29:08','2018-12-18 04:29:08','caution','untested','untested','untested'),('www.adclear.in','2018-12-27 10:02:04','2018-12-27 10:02:04','caution','untested','untested','untested'),('wowbabycare.com','2019-01-16 18:27:00','2019-01-16 18:27:00','caution','untested','untested','untested'),('calibration.airflite.com.au','2019-01-25 05:43:50','2019-01-25 05:43:50','caution','untested','safe','untested'),('sattamatkai.co','2019-01-26 19:09:00','2019-01-26 19:09:00','caution','untested','untested','untested'),('www.fashiontrend.com','2019-02-10 10:06:36','2019-02-10 10:06:36','caution','untested','safe','untested'),('fermenterskitchen.com','2019-02-10 16:10:00','2019-02-10 16:10:00','caution','untested','safe','untested'),('www.twohippieshemp.com','2019-02-20 10:54:53','2019-02-20 10:54:53','caution','untested','untested','untested'),('www.goliathcandc.com','2019-02-21 18:32:42','2019-02-23 22:09:23','caution','untested','untested','untested'),('www.apple.com','2019-02-21 18:33:26','2019-02-21 18:33:26','caution','untested','safe','untested'),('unitedweconnected.com','2019-02-24 08:02:01','2019-02-24 08:02:01','caution','untested','untested','untested'),('www.fsbwa.com','2019-02-24 18:28:07','2019-02-24 18:28:07','caution','untested','safe','untested');
/*!40000 ALTER TABLE `wt_diagnostic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wt_location`
--

DROP TABLE IF EXISTS `wt_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_location` (
  `Domain` varchar(90) NOT NULL,
  `Added` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(45) NOT NULL,
  `country_name` varchar(150) NOT NULL,
  `country_code` varchar(2) NOT NULL,
  `city` varchar(100) NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  `region_name` varchar(150) NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_location`
--

LOCK TABLES `wt_location` WRITE;
/*!40000 ALTER TABLE `wt_location` DISABLE KEYS */;
INSERT INTO `wt_location` (`Domain`, `Added`, `Modified`, `ip`, `country_name`, `country_code`, `city`, `latitude`, `longitude`, `region_name`) VALUES ('pageinsider.com','2016-03-08 08:03:09','2016-03-08 13:03:09','Unknown','Unknown','XX','Unknown',0,0,'Unknown'),('pdf.co.ke','2016-03-27 18:24:21','2016-03-27 22:24:21','Unknown','Unknown','XX','Unknown',0,0,'Unknown'),('farts.com','2018-12-18 04:30:30','2018-12-18 04:30:30','Unknown','Unknown','XX','Unknown',0,0,'Unknown'),('www.adclear.in','2018-12-27 10:01:26','2018-12-27 10:01:26','Unknown','Unknown','XX','Unknown',0,0,'Unknown'),('www.goliathcandc.com','2019-02-23 22:10:01','2019-02-23 22:10:01','Unknown','Unknown','XX','Unknown',0,0,'Unknown');
/*!40000 ALTER TABLE `wt_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wt_search`
--

DROP TABLE IF EXISTS `wt_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_search` (
  `Domain` varchar(90) NOT NULL,
  `Added` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `google` bigint(20) unsigned NOT NULL,
  `yahoo` bigint(20) unsigned NOT NULL,
  `yandex` bigint(20) unsigned NOT NULL,
  `bing` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_search`
--

LOCK TABLES `wt_search` WRITE;
/*!40000 ALTER TABLE `wt_search` DISABLE KEYS */;
INSERT INTO `wt_search` (`Domain`, `Added`, `Modified`, `google`, `yahoo`, `yandex`, `bing`) VALUES ('pageinsider.com','2016-03-08 08:03:23','2016-03-08 13:03:23',541000,206000,0,205000),('selfiesbabe.com','2016-03-24 22:04:01','2016-03-25 02:04:01',3980,27,0,0),('byeqima.com','2016-04-18 11:40:47','2016-04-18 15:40:47',932,455,0,0),('kelprestataires.com','2016-04-18 11:41:11','2016-04-18 15:41:11',314,13,0,0),('codeur.com','2016-04-18 11:41:31','2016-04-18 15:41:31',205000,22200,0,15),('devtool.info','2018-09-02 11:53:36','2018-09-02 11:53:36',1,0,0,0),('labelgunstore.com','2018-09-03 10:27:09','2018-09-03 10:27:09',655,155,0,0),('wowbabycare.com','2019-01-16 18:27:39','2019-02-10 09:52:21',293,0,0,1),('sss.com','2019-01-23 22:18:56','2019-01-23 22:18:56',1,0,0,0),('sattamatkai.co','2019-01-26 19:09:50','2019-01-26 19:09:50',39,0,0,0),('bitmagazine.pw','2019-01-30 19:49:10','2019-02-11 13:17:43',148,0,0,1),('wowpetssupply.com','2019-02-10 09:51:33','2019-02-10 09:51:33',151,0,0,0),('wowfashiontrend.com','2019-02-10 09:52:52','2019-02-10 09:52:52',303,0,0,0),('wowdiabetestips.com.com','2019-02-10 09:53:28','2019-02-10 09:53:28',0,0,0,0),('wowdiabetestips.com','2019-02-10 09:54:09','2019-02-10 09:54:09',47,0,0,0),('wowweightlosstips.com','2019-02-10 09:55:48','2019-02-10 09:55:48',393,0,0,0),('uniqueweightlosstips.com','2019-02-10 09:56:32','2019-02-10 09:56:32',27,0,0,0),('wowebooksale.com','2019-02-10 09:57:41','2019-02-10 09:57:42',50,64,0,0),('digitalbusinesshub.com','2019-02-10 09:58:17','2019-02-10 09:58:17',6,0,0,1),('wowfindgram.com','2019-02-10 09:59:20','2019-02-10 09:59:20',0,0,0,0),('webtargetedtraffic.com','2019-02-10 23:23:29','2019-02-10 23:23:29',200,2000,0,2000),('memonpropertypoint.com','2019-02-15 23:16:42','2019-02-15 23:16:42',1,0,0,0),('www.fsbwa.com','2019-02-21 18:35:08','2019-02-21 18:35:08',638,19100,0,19100),('www.goliathcandc.com','2019-02-21 18:35:46','2019-02-23 22:10:31',0,0,0,0);
/*!40000 ALTER TABLE `wt_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wt_social`
--

DROP TABLE IF EXISTS `wt_social`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_social` (
  `Domain` varchar(90) NOT NULL,
  `Added` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gplus` int(10) unsigned NOT NULL,
  `delicious` int(10) unsigned NOT NULL,
  `pinterest` int(10) unsigned NOT NULL,
  `linkedin` int(10) unsigned NOT NULL,
  `stumbleupon` int(10) unsigned NOT NULL,
  `twitter` int(10) unsigned NOT NULL,
  `share_count` int(10) unsigned NOT NULL,
  `like_count` int(10) unsigned NOT NULL,
  `comment_count` int(10) unsigned NOT NULL,
  `total_count` int(11) unsigned NOT NULL,
  `click_count` int(11) unsigned NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_social`
--

LOCK TABLES `wt_social` WRITE;
/*!40000 ALTER TABLE `wt_social` DISABLE KEYS */;
INSERT INTO `wt_social` (`Domain`, `Added`, `Modified`, `gplus`, `delicious`, `pinterest`, `linkedin`, `stumbleupon`, `twitter`, `share_count`, `like_count`, `comment_count`, `total_count`, `click_count`) VALUES ('pageinsider.com','2016-03-08 08:02:02','2016-03-08 13:02:02',12,0,0,8,8,0,62,36,27,125,0),('mailing.com','2016-03-19 17:32:24','2016-03-19 21:32:24',10,0,0,5,1,0,5,12,0,17,0),('selfiesbabe.com','2016-03-24 21:59:44','2016-03-25 01:59:44',339,0,0,0,1,0,165,1,2,168,0),('houseofprophets.com','2016-03-27 15:43:01','2016-03-27 19:43:01',0,0,0,0,0,0,1,0,0,1,0),('www.healthtttips.blogspot.com','2016-03-28 09:35:05','2016-03-28 13:35:05',0,0,0,0,0,0,0,0,0,0,0),('flippa.com','2016-03-28 21:39:57','2016-03-29 01:39:57',2141,0,1,304,345,0,2548,549,408,3505,0),('www.thenewsgadget.com','2016-04-01 12:18:55','2016-04-01 16:18:55',0,0,0,0,5,0,95,13,0,108,0),('thenewsgadget.com','2016-04-01 12:19:52','2016-04-01 16:19:52',0,0,0,0,5,0,95,13,0,108,0),('cools4u.com','2016-04-24 15:38:10','2016-04-24 19:38:10',4,0,0,0,1,0,5489,213,75,5777,12),('usersearch.org','2016-04-25 15:11:25','2016-04-25 19:11:25',11,0,0,64,0,0,943,118,1031,2092,0),('google.com','2018-09-26 10:19:52','2018-09-26 10:19:52',0,0,11278,0,0,0,0,0,0,0,0),('sattamatkai.co','2019-01-26 19:11:05','2019-01-26 19:11:05',0,0,0,0,0,0,0,0,0,0,0),('matkaplay.net','2019-01-26 19:11:42','2019-01-26 19:11:42',0,0,0,0,0,0,0,0,0,0,0),('wowfashiontrend.com','2019-02-10 10:01:18','2019-02-10 10:01:18',0,0,0,0,0,0,0,0,0,0,0),('renewcbdstore.com','2019-02-10 17:12:02','2019-02-10 17:12:02',0,0,0,0,0,0,0,0,0,0,0),('webtargetedtraffic.com','2019-02-10 23:24:18','2019-02-10 23:24:18',0,0,0,0,0,0,0,0,0,0,0),('bitmagazine.pw','2019-02-11 13:18:45','2019-02-11 13:18:45',0,0,0,0,0,0,0,0,0,0,0),('memonpropertypoint.com','2019-02-15 23:17:48','2019-02-15 23:17:48',0,0,0,0,0,0,0,0,0,0,0),('three18media.com','2019-02-18 22:15:51','2019-02-18 22:15:51',0,0,0,0,0,0,0,0,0,0,0),('www.fsbwa.com','2019-02-24 18:27:15','2019-02-24 18:27:15',0,0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `wt_social` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wt_whois`
--

DROP TABLE IF EXISTS `wt_whois`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_whois` (
  `Domain` varchar(90) NOT NULL,
  `Added` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Whois` text NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_whois`
--

LOCK TABLES `wt_whois` WRITE;
/*!40000 ALTER TABLE `wt_whois` DISABLE KEYS */;
INSERT INTO `wt_whois` (`Domain`, `Added`, `Modified`, `Whois`) VALUES ('gizoom.com','2016-03-27 05:21:57','2016-03-27 09:21:57','Domain Name: gizoom.com\r\nRegistry Domain ID: 147222003_DOMAIN_COM-VRSN\r\nRegistrar WHOIS Server: whois.godaddy.com\r\nRegistrar URL: http://www.godaddy.com\r\nUpdate Date: 2016-03-12T05:18:50Z\r\nCreation Date: 2005-03-20T21:51:20Z\r\nRegistrar Registration Expiration Date: 2018-03-20T20:51:20Z\r\nRegistrar: GoDaddy.com, LLC\r\nRegistrar IANA ID: 146\r\nRegistrar Abuse Contact Email: abuse@godaddy.com\r\nRegistrar Abuse Contact Phone: +1.4806242505\r\nDomain Status: clientTransferProhibited http://www.icann.org/epp#clientTransferProhibited\r\nDomain Status: clientUpdateProhibited http://www.icann.org/epp#clientUpdateProhibited\r\nDomain Status: clientRenewProhibited http://www.icann.org/epp#clientRenewProhibited\r\nDomain Status: clientDeleteProhibited http://www.icann.org/epp#clientDeleteProhibited\r\nRegistry Registrant ID: Not Available From Registry\r\nRegistrant Name: Paul Conant\r\nRegistrant Organization: \r\nRegistrant Street: 1305 Post Road\r\nRegistrant City: Fairfield\r\nRegistrant State/Province: None Selected\r\nRegistrant Postal Code: 06824\r\nRegistrant Country: US\r\nRegistrant Phone: +1.2032559399\r\nRegistrant Phone Ext: \r\nRegistrant Fax: \r\nRegistrant Fax Ext: \r\nRegistrant Email: paul@gizoom.com\r\nRegistry Admin ID: Not Available From Registry\r\nAdmin Name: Paul Conant\r\nAdmin Organization: \r\nAdmin Street: 1305 Post Road\r\nAdmin City: Fairfield\r\nAdmin State/Province: None Selected\r\nAdmin Postal Code: 06824\r\nAdmin Country: US\r\nAdmin Phone: +1.2032559399\r\nAdmin Phone Ext: \r\nAdmin Fax: \r\nAdmin Fax Ext: \r\nAdmin Email: paul@gizoom.com\r\nRegistry Tech ID: Not Available From Registry\r\nTech Name: Paul Conant\r\nTech Organization: \r\nTech Street: 1305 Post Road\r\nTech City: Fairfield\r\nTech State/Province: CT\r\nTech Postal Code: 06824\r\nTech Country: US\r\nTech Phone: +1.2032559399\r\nTech Phone Ext: \r\nTech Fax: \r\nTech Fax Ext: \r\nTech Email: nocontactsfound@secureserver.net\r\nName Server: NS75.DOMAINCONTROL.COM\r\nName Server: NS76.DOMAINCONTROL.COM\r\nDNSSEC: unsigned\r\nURL of the ICANN WHOIS Data Problem Reporting System: http://wdprs.internic.net/\r\n>>> Last update of WHOIS database: 2016-03-27T10:00:00Z <<<\r\n\r\nFor more information on Whois status codes, please visit https://www.icann.org/resources/pages/epp-status-codes-2014-06-16-en\r\n\r\nThe data contained in GoDaddy.com, LLC\'s WhoIs database,\r\nwhile believed by the company to be reliable, is provided \"as is\"\r\nwith no guarantee or warranties regarding its accuracy.  This\r\ninformation is provided for the sole purpose of assisting you\r\nin obtaining information about domain name registration records.\r\nAny use of this data for any other purpose is expressly forbidden without the prior written\r\npermission of GoDaddy.com, LLC.  By submitting an inquiry,\r\nyou agree to these terms of usage and limitations of warranty.  In particular,\r\nyou agree not to use this data to allow, enable, or otherwise make possible,\r\ndissemination or collection of this data, in part or in its entirety, for any\r\npurpose, such as the transmission of unsolicited advertising and\r\nand solicitations of any kind, including spam.  You further agree\r\nnot to use this data to enable high volume, automated or robotic electronic\r\nprocesses designed to collect or compile this data for any purpose,\r\nincluding mining this data for your own personal or commercial purposes. \r\n\r\nPlease note: the registrant of the domain name is specified\r\nin the \"registrant\" section.  In most cases, GoDaddy.com, LLC \r\nis not the registrant of domain names listed in this database.\r\n'),('pdf.co.ke','2016-03-27 18:25:18','2016-03-27 22:25:18','Domain Name: co.ke\nDomain ID: 3-KENIC\nWHOIS Server: \nReferral URL: \nUpdated Date: 2015-05-11T05:39:12.830Z\nCreation Date: 2009-05-14T08:34:56.443Z\nRegistry Expiry Date: 2016-05-14T08:34:56.426Z\nSponsoring Registrar: root\nSponsoring Registrar IANA ID: \nDomain Status: ok\nName Server: mzizi.kenic.or.ke\nName Server: ns1.coza.net.za\nDNSSEC: unsigned\nAdditional Section\nSponsoring Registrar URL: \nSponsoring Registrar Address: P.O. Box 1461  Nairobi - 00606  Waiyaki Way\nSponsoring Registrar Country: KE\nSponsoring Registrar Phone: \nSponsoring Registrar Fax: \nSponsoring Registrar Customer Service Contact: \nSponsoring Registrar Customer Service Email: registry@kenic.or.ke\nSponsoring Registrar Admin Contact: \nSponsoring Registrar Admin Email: registry@kenic.or.ke\n>>> Last update of WHOIS database: 2016-03-27T22:20:31.934Z <<<\n\n% Copyright KENIC\r\n\r\n%  The data below is provided for information purposes\r\n%  and to assist persons in obtaining information about or\r\n%  related to domain name registrations.\r\n%  By submitting a whois query, you agree to use this data\r\n%  only for lawful purposes.\r\n\r\n\r\n% remarks:     Security issues should also be addressed to noc@kenic.or.ke\r\n% remarks:     Mail abuse issues should also be addressed to abuse@kenic.or.ke\r\n \r\n% whois.kenic.or.ke accepts only direct match queries.\r\n% Types of queries are: domains (.KE) and POCs.\n'),('usdigitalconsulting.com','2016-03-27 20:38:53','2016-03-28 00:38:53','Domain Name: usdigitalconsulting.com\r\nRegistry Domain ID: 2000299415_DOMAIN_COM-VRSN\r\nRegistrar WHOIS Server: whois.godaddy.com\r\nRegistrar URL: http://www.godaddy.com\r\nUpdate Date: 2016-02-04T20:44:56Z\r\nCreation Date: 2016-02-04T20:44:56Z\r\nRegistrar Registration Expiration Date: 2018-02-04T20:44:56Z\r\nRegistrar: GoDaddy.com, LLC\r\nRegistrar IANA ID: 146\r\nRegistrar Abuse Contact Email: abuse@godaddy.com\r\nRegistrar Abuse Contact Phone: +1.4806242505\r\nDomain Status: clientTransferProhibited http://www.icann.org/epp#clientTransferProhibited\r\nDomain Status: clientUpdateProhibited http://www.icann.org/epp#clientUpdateProhibited\r\nDomain Status: clientRenewProhibited http://www.icann.org/epp#clientRenewProhibited\r\nDomain Status: clientDeleteProhibited http://www.icann.org/epp#clientDeleteProhibited\r\nRegistry Registrant ID: Not Available From Registry\r\nRegistrant Name: Ian Faler\r\nRegistrant Organization: Stocks Sources\r\nRegistrant Street: 10622 Monticello\r\nRegistrant City: Pinckney\r\nRegistrant State/Province: Michigan\r\nRegistrant Postal Code: 48169\r\nRegistrant Country: US\r\nRegistrant Phone: +1.8103331028\r\nRegistrant Phone Ext: \r\nRegistrant Fax: \r\nRegistrant Fax Ext: \r\nRegistrant Email: ibfa7@yahoo.com\r\nRegistry Admin ID: Not Available From Registry\r\nAdmin Name: Ian Faler\r\nAdmin Organization: Stocks Sources\r\nAdmin Street: 10622 Monticello\r\nAdmin City: Pinckney\r\nAdmin State/Province: Michigan\r\nAdmin Postal Code: 48169\r\nAdmin Country: US\r\nAdmin Phone: +1.8103331028\r\nAdmin Phone Ext: \r\nAdmin Fax: \r\nAdmin Fax Ext: \r\nAdmin Email: ibfa7@yahoo.com\r\nRegistry Tech ID: Not Available From Registry\r\nTech Name: Ian Faler\r\nTech Organization: Stocks Sources\r\nTech Street: 10622 Monticello\r\nTech City: Pinckney\r\nTech State/Province: Michigan\r\nTech Postal Code: 48169\r\nTech Country: US\r\nTech Phone: +1.8103331028\r\nTech Phone Ext: \r\nTech Fax: \r\nTech Fax Ext: \r\nTech Email: ibfa7@yahoo.com\r\nName Server: NS1.BLUEHOST.COM\r\nName Server: NS2.BLUEHOST.COM\r\nDNSSEC: unsigned\r\nURL of the ICANN WHOIS Data Problem Reporting System: http://wdprs.internic.net/\r\n>>> Last update of WHOIS database: 2016-03-28T01:00:00Z <<<\r\n\r\nFor more information on Whois status codes, please visit https://www.icann.org/resources/pages/epp-status-codes-2014-06-16-en\r\n\r\nThe data contained in GoDaddy.com, LLC\'s WhoIs database,\r\nwhile believed by the company to be reliable, is provided \"as is\"\r\nwith no guarantee or warranties regarding its accuracy.  This\r\ninformation is provided for the sole purpose of assisting you\r\nin obtaining information about domain name registration records.\r\nAny use of this data for any other purpose is expressly forbidden without the prior written\r\npermission of GoDaddy.com, LLC.  By submitting an inquiry,\r\nyou agree to these terms of usage and limitations of warranty.  In particular,\r\nyou agree not to use this data to allow, enable, or otherwise make possible,\r\ndissemination or collection of this data, in part or in its entirety, for any\r\npurpose, such as the transmission of unsolicited advertising and\r\nand solicitations of any kind, including spam.  You further agree\r\nnot to use this data to enable high volume, automated or robotic electronic\r\nprocesses designed to collect or compile this data for any purpose,\r\nincluding mining this data for your own personal or commercial purposes. \r\n\r\nPlease note: the registrant of the domain name is specified\r\nin the \"registrant\" section.  In most cases, GoDaddy.com, LLC \r\nis not the registrant of domain names listed in this database.\r\n'),('freetool.info','2016-04-12 19:24:16','2016-04-12 23:24:16','Domain Name: FREETOOL.INFO\r\nDomain ID: D503300000004927178-LRMS\r\nWHOIS Server:\r\nReferral URL: http://www.godaddy.com\r\nUpdated Date: 2016-03-08T07:34:55Z\r\nCreation Date: 2016-02-14T00:06:55Z\r\nRegistry Expiry Date: 2017-02-14T00:06:55Z\r\nSponsoring Registrar: GoDaddy.com, LLC\r\nSponsoring Registrar IANA ID: 146\r\nDomain Status: clientDeleteProhibited https://icann.org/epp#clientDeleteProhibited\r\nDomain Status: clientRenewProhibited https://icann.org/epp#clientRenewProhibited\r\nDomain Status: clientTransferProhibited https://icann.org/epp#clientTransferProhibited\r\nDomain Status: clientUpdateProhibited https://icann.org/epp#clientUpdateProhibited\r\nDomain Status: serverTransferProhibited https://icann.org/epp#serverTransferProhibited\r\nRegistrant ID: CR231958607\r\nRegistrant Name: MARTIN TURGEON\r\nRegistrant Organization:\r\nRegistrant Street: 21 Denis st.\r\nRegistrant Street: Box 3073\r\nRegistrant City: Hearst\r\nRegistrant State/Province: Ontario\r\nRegistrant Postal Code: P0L1N0\r\nRegistrant Country: CA\r\nRegistrant Phone: +1.7053725663\r\nRegistrant Phone Ext:\r\nRegistrant Fax:\r\nRegistrant Fax Ext:\r\nRegistrant Email: turgeonm3@gmail.com\r\nAdmin ID: CR231958610\r\nAdmin Name: Martin Turgeon\r\nAdmin Organization:\r\nAdmin Street: 21 Denis st.\r\nAdmin Street: box 3073\r\nAdmin City: Hearst\r\nAdmin State/Province: Ontario\r\nAdmin Postal Code: P0L 1N0\r\nAdmin Country: CA\r\nAdmin Phone: +1.7053725663\r\nAdmin Phone Ext:\r\nAdmin Fax:\r\nAdmin Fax Ext:\r\nAdmin Email: turgeonm3@gmail.com\r\nTech ID: CR231958609\r\nTech Name: Martin Turgeon\r\nTech Organization:\r\nTech Street: 21 Denis st.\r\nTech Street: box 3073\r\nTech City: Hearst\r\nTech State/Province: Ontario\r\nTech Postal Code: P0L 1N0\r\nTech Country: CA\r\nTech Phone: +1.7053725663\r\nTech Phone Ext:\r\nTech Fax:\r\nTech Fax Ext:\r\nTech Email: turgeonm3@gmail.com\r\nBilling ID: CR231958611\r\nBilling Name: Martin Turgeon\r\nBilling Organization:\r\nBilling Street: 21 Denis st.\r\nBilling Street: box 3073\r\nBilling City: Hearst\r\nBilling State/Province: Ontario\r\nBilling Postal Code: P0L 1N0\r\nBilling Country: CA\r\nBilling Phone: +1.7053725663\r\nBilling Phone Ext:\r\nBilling Fax:\r\nBilling Fax Ext:\r\nBilling Email: turgeonm3@gmail.com\r\nName Server: NS2.TURGEONVPS.COM\r\nName Server: NS1.TURGEONVPS.COM\r\nDNSSEC: unsigned\r\n>>> Last update of WHOIS database: 2016-04-12T03:20:59Z <<<\r\n\r\n\"For more information on Whois status codes, please visit https://icann.org/epp\"\r\n\r\nAccess to AFILIAS WHOIS information is provided to assist persons in determining the contents of a domain name registration record in the Afilias registry database. The data in this record is provided by Afilias Limited for informational purposes only, and Afilias does not guarantee its accuracy.  This service is intended only for query-based access. You agree that you will use this data only for lawful purposes and that, under no circumstances will you use this data to(a) allow, enable, or otherwise support the transmission by e-mail, telephone, or facsimile of mass unsolicited, commercial advertising or solicitations to entities other than the data recipient\'s own existing customers; or (b) enable high volume, automated, electronic processes that send queries or data to the systems of Registry Operator, a Registrar, or Afilias except as reasonably necessary to register domain names or modify existing registrations. All rights reserved. Afilias reserves the right to modify these terms at any time. By submitting this query, you agree to abide by this policy.\r\n'),('jobhelp.online','2016-04-26 02:23:40','2016-04-26 06:23:40','Domain Name: JOBHELP.ONLINE\r\nDomain ID: D18817336-CNIC\r\nWHOIS Server: whois.PublicDomainRegistry.com\r\nReferral URL:\r\nUpdated Date: 2016-03-26T03:01:15.0Z\r\nCreation Date: 2016-03-21T02:44:09.0Z\r\nRegistry Expiry Date: 2017-03-21T23:59:59.0Z\r\nSponsoring Registrar: PDR Ltd. d/b/a PublicDomainRegistry.com\r\nSponsoring Registrar IANA ID: 303\r\nDomain Status: serverTransferProhibited https://icann.org/epp#serverTransferProhibited\r\nDomain Status: clientTransferProhibited https://icann.org/epp#clientTransferProhibited\r\nRegistrant ID: C44961668-CNIC\r\nRegistrant Name: bipin dubey\r\nRegistrant Organization: N/A\r\nRegistrant Street: 736 dda flat pocket c\r\nRegistrant City: new delhi\r\nRegistrant State/Province: Other\r\nRegistrant Postal Code: 110041\r\nRegistrant Country: IN\r\nRegistrant Phone: +91.9717912630\r\nRegistrant Phone Ext:\r\nRegistrant Fax:\r\nRegistrant Fax Ext:\r\nRegistrant Email: insbipin@gmail.com\r\nAdmin ID: C44961668-CNIC\r\nAdmin Name: bipin dubey\r\nAdmin Organization: N/A\r\nAdmin Street: 736 dda flat pocket c\r\nAdmin City: new delhi\r\nAdmin State/Province: Other\r\nAdmin Postal Code: 110041\r\nAdmin Country: IN\r\nAdmin Phone: +91.9717912630\r\nAdmin Phone Ext:\r\nAdmin Fax:\r\nAdmin Fax Ext:\r\nAdmin Email: insbipin@gmail.com\r\nTech ID: C44961668-CNIC\r\nTech Name: bipin dubey\r\nTech Organization: N/A\r\nTech Street: 736 dda flat pocket c\r\nTech City: new delhi\r\nTech State/Province: Other\r\nTech Postal Code: 110041\r\nTech Country: IN\r\nTech Phone: +91.9717912630\r\nTech Phone Ext:\r\nTech Fax:\r\nTech Fax Ext:\r\nTech Email: insbipin@gmail.com\r\nName Server: NS02.000WEBHOST.COM\r\nName Server: NS01.000WEBHOST.COM\r\nDNSSEC: unsigned\r\nBilling ID: C44961668-CNIC\r\nBilling Name: bipin dubey\r\nBilling Organization: N/A\r\nBilling Street: 736 dda flat pocket c\r\nBilling City: new delhi\r\nBilling State/Province: Other\r\nBilling Postal Code: 110041\r\nBilling Country: IN\r\nBilling Phone: +91.9717912630\r\nBilling Phone Ext:\r\nBilling Fax:\r\nBilling Fax Ext:\r\nBilling Email: insbipin@gmail.com\r\n>>> Last update of WHOIS database: 2016-04-26T07:23:41.0Z <<<\r\n\r\nFor more information on Whois status codes, please visit https://icann.org/epp\r\n\r\nThis whois service is provided by CentralNic Ltd and only contains\r\ninformation pertaining to Internet domain names registered by our\r\nour customers. By using this service you are agreeing (1) not to use any\r\ninformation presented here for any purpose other than determining\r\nownership of domain names, (2) not to store or reproduce this data in\r\nany way, (3) not to use any high-volume, automated, electronic processes\r\nto obtain data from this service. Abuse of this service is monitored and\r\nactions in contravention of these terms will result in being permanently\r\nblacklisted. All data is (c) CentralNic Ltd https://www.centralnic.com/\r\n\r\nAccess to the whois service is rate limited. For more information, please\r\nsee https://registrar-console.centralnic.com/pub/whois_guidance.\r\n\r\n'),('google.com','2018-09-26 10:17:07','2018-09-26 10:17:07','   Domain Name: GOOGLE.COM\r\n   Registry Domain ID: 2138514_DOMAIN_COM-VRSN\r\n   Registrar WHOIS Server: whois.markmonitor.com\r\n   Registrar URL: http://www.markmonitor.com\r\n   Updated Date: 2018-02-21T18:36:40Z\r\n   Creation Date: 1997-09-15T04:00:00Z\r\n   Registry Expiry Date: 2020-09-14T04:00:00Z\r\n   Registrar: MarkMonitor Inc.\r\n   Registrar IANA ID: 292\r\n   Registrar Abuse Contact Email: abusecomplaints@markmonitor.com\r\n   Registrar Abuse Contact Phone: +1.2083895740\r\n   Domain Status: clientDeleteProhibited https://icann.org/epp#clientDeleteProhibited\r\n   Domain Status: clientTransferProhibited https://icann.org/epp#clientTransferProhibited\r\n   Domain Status: clientUpdateProhibited https://icann.org/epp#clientUpdateProhibited\r\n   Domain Status: serverDeleteProhibited https://icann.org/epp#serverDeleteProhibited\r\n   Domain Status: serverTransferProhibited https://icann.org/epp#serverTransferProhibited\r\n   Domain Status: serverUpdateProhibited https://icann.org/epp#serverUpdateProhibited\r\n   Name Server: NS1.GOOGLE.COM\r\n   Name Server: NS2.GOOGLE.COM\r\n   Name Server: NS3.GOOGLE.COM\r\n   Name Server: NS4.GOOGLE.COM\r\n   DNSSEC: unsigned\r\n   URL of the ICANN Whois Inaccuracy Complaint Form: https://www.icann.org/wicf/\r\n>>> Last update of whois database: 2018-09-26T10:17:03Z <<<\r\n\r\nFor more information on Whois status codes, please visit https://icann.org/epp\r\n\r\nNOTICE: The expiration date displayed in this record is the date the\r\nregistrar\'s sponsorship of the domain name registration in the registry is\r\ncurrently set to expire. This date does not necessarily reflect the expiration\r\ndate of the domain name registrant\'s agreement with the sponsoring\r\nregistrar.  Users may consult the sponsoring registrar\'s Whois database to\r\nview the registrar\'s reported date of expiration for this registration.\r\n\r\nTERMS OF USE: You are not authorized to access or query our Whois\r\ndatabase through the use of electronic processes that are high-volume and\r\nautomated except as reasonably necessary to register domain names or\r\nmodify existing registrations; the Data in VeriSign Global Registry\r\nServices\' (\"VeriSign\") Whois database is provided by VeriSign for\r\ninformation purposes only, and to assist persons in obtaining information\r\nabout or related to a domain name registration record. VeriSign does not\r\nguarantee its accuracy. By submitting a Whois query, you agree to abide\r\nby the following terms of use: You agree that you may use this Data only\r\nfor lawful purposes and that under no circumstances will you use this Data\r\nto: (1) allow, enable, or otherwise support the transmission of mass\r\nunsolicited, commercial advertising or solicitations via e-mail, telephone,\r\nor facsimile; or (2) enable high volume, automated, electronic processes\r\nthat apply to VeriSign (or its computer systems). The compilation,\r\nrepackaging, dissemination or other use of this Data is expressly\r\nprohibited without the prior written consent of VeriSign. You agree not to\r\nuse electronic processes that are automated and high-volume to access or\r\nquery the Whois database except as reasonably necessary to register\r\ndomain names or modify existing registrations. VeriSign reserves the right\r\nto restrict your access to the Whois database in its sole discretion to ensure\r\noperational stability.  VeriSign may restrict or terminate your access to the\r\nWhois database for failure to abide by these terms of use. VeriSign\r\nreserves the right to modify these terms at any time.\r\n\r\nThe Registry database contains ONLY .COM, .NET, .EDU domains and\r\nRegistrars.\r\n'),('bitmagazine.pw','2019-01-30 19:51:09','2019-01-30 19:51:09','This TLD has no whois server.\n'),('nicheonlinetraffic.com','2019-02-10 23:22:20','2019-02-10 23:22:20','   Domain Name: NICHEONLINETRAFFIC.COM\r\n   Registry Domain ID: 2304759930_DOMAIN_COM-VRSN\r\n   Registrar WHOIS Server: whois.godaddy.com\r\n   Registrar URL: http://www.godaddy.com\r\n   Updated Date: 2018-12-03T10:08:48Z\r\n   Creation Date: 2018-09-01T02:19:52Z\r\n   Registry Expiry Date: 2019-09-01T02:19:52Z\r\n   Registrar: GoDaddy.com, LLC\r\n   Registrar IANA ID: 146\r\n   Registrar Abuse Contact Email: abuse@godaddy.com\r\n   Registrar Abuse Contact Phone: 480-624-2505\r\n   Domain Status: clientDeleteProhibited https://icann.org/epp#clientDeleteProhibited\r\n   Domain Status: clientRenewProhibited https://icann.org/epp#clientRenewProhibited\r\n   Domain Status: clientTransferProhibited https://icann.org/epp#clientTransferProhibited\r\n   Domain Status: clientUpdateProhibited https://icann.org/epp#clientUpdateProhibited\r\n   Name Server: DOM.NS.CLOUDFLARE.COM\r\n   Name Server: LEAH.NS.CLOUDFLARE.COM\r\n   DNSSEC: unsigned\r\n   URL of the ICANN Whois Inaccuracy Complaint Form: https://www.icann.org/wicf/\r\n>>> Last update of whois database: 2019-02-10T23:22:05Z <<<\r\n\r\nFor more information on Whois status codes, please visit https://icann.org/epp\r\n\r\nNOTICE: The expiration date displayed in this record is the date the\r\nregistrar\'s sponsorship of the domain name registration in the registry is\r\ncurrently set to expire. This date does not necessarily reflect the expiration\r\ndate of the domain name registrant\'s agreement with the sponsoring\r\nregistrar.  Users may consult the sponsoring registrar\'s Whois database to\r\nview the registrar\'s reported date of expiration for this registration.\r\n\r\nTERMS OF USE: You are not authorized to access or query our Whois\r\ndatabase through the use of electronic processes that are high-volume and\r\nautomated except as reasonably necessary to register domain names or\r\nmodify existing registrations; the Data in VeriSign Global Registry\r\nServices\' (\"VeriSign\") Whois database is provided by VeriSign for\r\ninformation purposes only, and to assist persons in obtaining information\r\nabout or related to a domain name registration record. VeriSign does not\r\nguarantee its accuracy. By submitting a Whois query, you agree to abide\r\nby the following terms of use: You agree that you may use this Data only\r\nfor lawful purposes and that under no circumstances will you use this Data\r\nto: (1) allow, enable, or otherwise support the transmission of mass\r\nunsolicited, commercial advertising or solicitations via e-mail, telephone,\r\nor facsimile; or (2) enable high volume, automated, electronic processes\r\nthat apply to VeriSign (or its computer systems). The compilation,\r\nrepackaging, dissemination or other use of this Data is expressly\r\nprohibited without the prior written consent of VeriSign. You agree not to\r\nuse electronic processes that are automated and high-volume to access or\r\nquery the Whois database except as reasonably necessary to register\r\ndomain names or modify existing registrations. VeriSign reserves the right\r\nto restrict your access to the Whois database in its sole discretion to ensure\r\noperational stability.  VeriSign may restrict or terminate your access to the\r\nWhois database for failure to abide by these terms of use. VeriSign\r\nreserves the right to modify these terms at any time.\r\n\r\nThe Registry database contains ONLY .COM, .NET, .EDU domains and\r\nRegistrars.\r\n'),('bestwebhosting.co.uk','2019-02-21 20:00:01','2019-02-21 20:00:01','    Domain name:\r\n        co.uk\r\n\r\n    Registrant:\r\n        Nominet UK\r\n\r\n    Registrant type:\r\n        UK Limited Company, (Company number: 3203859)\r\n\r\n    Registrant\'s address:\r\n        Minerva House\r\n        Edmund Halley Road\r\n        Oxford Science Park\r\n        Oxford\r\n        OX4 4DQ\r\n        GB\r\n\r\n    Registrar:\r\n        No registrar listed.  This domain is directly registered with Nominet.\r\n\r\n    Relevant dates:\r\n        Registered on: before Aug-1996\r\n        Last updated:  16-Nov-2004\r\n\r\n    Registration status:\r\n        No registration status listed.\r\n\r\n    Name servers:\r\n        dns1.nic.uk.        213.248.216.1       2a01:618:400::1\r\n        dns2.nic.uk.        103.49.80.1       2401:fd80:400::1\r\n        dns3.nic.uk.        213.248.220.1       2a01:618:404::1\r\n        dns4.nic.uk.        43.230.48.1       2401:fd80:404::1\r\n        nsa.nic.uk.        156.154.100.3       2001:502:ad09::3\r\n        nsb.nic.uk.        156.154.101.3       \r\n        nsc.nic.uk.        156.154.102.3       \r\n        nsd.nic.uk.        156.154.103.3       \r\n\r\n\r\n    WHOIS lookup made at 20:00:01 21-Feb-2019\r\n\r\n-- \r\nThis WHOIS information is provided for free by Nominet UK the central registry\r\nfor .uk domain names. This information and the .uk WHOIS are:\r\n\r\n    Copyright Nominet UK 1996 - 2019.\r\n\r\nYou may not access the .uk WHOIS or use any data from it except as permitted\r\nby the terms of use available in full at https://www.nominet.uk/whoisterms,\r\nwhich includes restrictions on: (A) use of the data for advertising, or its\r\nrepackaging, recompilation, redistribution or reuse (B) obscuring, removing\r\nor hiding any or all of this notice and (C) exceeding query rate or volume\r\nlimits. The data is provided on an \'as-is\' basis and may lag behind the\r\nregister. Access may be withdrawn or restricted at any time. \r\n');
/*!40000 ALTER TABLE `wt_whois` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'devtool_databas'
--

--
-- Dumping routines for database 'devtool_databas'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-25  1:09:32
