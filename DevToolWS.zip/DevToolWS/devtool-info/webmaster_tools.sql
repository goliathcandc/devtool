-- MySQL dump 10.13  Distrib 5.6.12, for Win64 (x86_64)
--
-- Host: localhost    Database: webmaster_toolkit
-- ------------------------------------------------------
-- Server version	5.6.12-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wt_alexa`
--

DROP TABLE IF EXISTS `wt_alexa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_alexa` (
  `Domain` varchar(90) NOT NULL,
  `Added` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `linksin` int(10) unsigned NOT NULL,
  `review_count` int(10) unsigned NOT NULL,
  `review_avg` float NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `country_code` varchar(2) NOT NULL,
  `country_name` varchar(100) NOT NULL,
  `country_rank` int(10) unsigned NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_alexa`
--

LOCK TABLES `wt_alexa` WRITE;
/*!40000 ALTER TABLE `wt_alexa` DISABLE KEYS */;
/*!40000 ALTER TABLE `wt_alexa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wt_backlinks`
--

DROP TABLE IF EXISTS `wt_backlinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_backlinks` (
  `Domain` varchar(90) NOT NULL,
  `Added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Cnt` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_backlinks`
--

LOCK TABLES `wt_backlinks` WRITE;
/*!40000 ALTER TABLE `wt_backlinks` DISABLE KEYS */;
/*!40000 ALTER TABLE `wt_backlinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wt_catalog`
--

DROP TABLE IF EXISTS `wt_catalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_catalog` (
  `Domain` varchar(90) NOT NULL,
  `Added` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dmoz` int(10) unsigned NOT NULL,
  `yandex` int(10) unsigned NOT NULL,
  `yahoo` int(10) unsigned NOT NULL,
  `alexa` int(10) unsigned NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_catalog`
--

LOCK TABLES `wt_catalog` WRITE;
/*!40000 ALTER TABLE `wt_catalog` DISABLE KEYS */;
/*!40000 ALTER TABLE `wt_catalog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wt_diagnostic`
--

DROP TABLE IF EXISTS `wt_diagnostic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_diagnostic` (
  `Domain` varchar(90) NOT NULL,
  `Added` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `google` enum('safe','warning','caution','untested') NOT NULL,
  `mcafee` enum('safe','warning','caution','untested') NOT NULL,
  `norton` enum('safe','warning','caution','untested') NOT NULL,
  `avg` enum('safe','warning','caution','untested') NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_diagnostic`
--

LOCK TABLES `wt_diagnostic` WRITE;
/*!40000 ALTER TABLE `wt_diagnostic` DISABLE KEYS */;
/*!40000 ALTER TABLE `wt_diagnostic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wt_location`
--

DROP TABLE IF EXISTS `wt_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_location` (
  `Domain` varchar(90) NOT NULL,
  `Added` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(45) NOT NULL,
  `country_name` varchar(150) NOT NULL,
  `country_code` varchar(2) NOT NULL,
  `city` varchar(100) NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  `region_name` varchar(150) NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_location`
--

LOCK TABLES `wt_location` WRITE;
/*!40000 ALTER TABLE `wt_location` DISABLE KEYS */;
/*!40000 ALTER TABLE `wt_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wt_search`
--

DROP TABLE IF EXISTS `wt_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_search` (
  `Domain` varchar(90) NOT NULL,
  `Added` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `google` bigint(20) unsigned NOT NULL,
  `yahoo` bigint(20) unsigned NOT NULL,
  `yandex` bigint(20) unsigned NOT NULL,
  `bing` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_search`
--

LOCK TABLES `wt_search` WRITE;
/*!40000 ALTER TABLE `wt_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `wt_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wt_social`
--

DROP TABLE IF EXISTS `wt_social`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_social` (
  `Domain` varchar(90) NOT NULL,
  `Added` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gplus` int(10) unsigned NOT NULL,
  `delicious` int(10) unsigned NOT NULL,
  `pinterest` int(10) unsigned NOT NULL,
  `linkedin` int(10) unsigned NOT NULL,
  `stumbleupon` int(10) unsigned NOT NULL,
  `twitter` int(10) unsigned NOT NULL,
  `share_count` int(10) unsigned NOT NULL,
  `like_count` int(10) unsigned NOT NULL,
  `comment_count` int(10) unsigned NOT NULL,
  `total_count` int(11) unsigned NOT NULL,
  `click_count` int(11) unsigned NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_social`
--

LOCK TABLES `wt_social` WRITE;
/*!40000 ALTER TABLE `wt_social` DISABLE KEYS */;
/*!40000 ALTER TABLE `wt_social` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wt_whois`
--

DROP TABLE IF EXISTS `wt_whois`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wt_whois` (
  `Domain` varchar(90) NOT NULL,
  `Added` datetime NOT NULL,
  `Modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Whois` text NOT NULL,
  PRIMARY KEY (`Domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wt_whois`
--

LOCK TABLES `wt_whois` WRITE;
/*!40000 ALTER TABLE `wt_whois` DISABLE KEYS */;
/*!40000 ALTER TABLE `wt_whois` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-09-01 22:03:24
