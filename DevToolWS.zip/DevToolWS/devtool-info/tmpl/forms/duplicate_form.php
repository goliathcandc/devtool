<div class="form-area thumbnail">

<div class="control-group">
<label for="text" class="control-label">Input your text here &darr;</label>
<div class="controls">
<textarea id="text" rows="5" class="input-block-level"></textarea>
<p><strong>Options</strong></p>
<textarea id="separator" class="in-table input-mini"></textarea>
<span class="help-inline">Separator (leave empty if it's space)</span>
</div>
</div>

<br/>
<button onclick="rmdp()" class="btn btn-large btn-primary">Remove duplicates</button>

<br/>
<br/>
<div class="control-group">
<label for="result" class="control-label">Result</label>
<div class="controls">
<textarea id="res" name="text" rows="5" class="input-block-level"></textarea>
</div>
</div>

</div>