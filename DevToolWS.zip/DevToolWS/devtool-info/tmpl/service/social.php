<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">Social Analytics</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/social_large.png"/>
You can use this free online tool to track like count, shares, tweets and more information about domain
provided by public API's.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."default_form.php"; ?>
<div class="clearfix"></div>
<div id="ajax_response"></div>
</div>
</div>
</div>
<div class="clearfix"></div>