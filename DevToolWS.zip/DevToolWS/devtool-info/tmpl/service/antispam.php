<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">Antispam Protector</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/antispam_large.png"/>
This free online tool allows you to protect your text from spammers.
In addition, you can customize the image, depending on your website design.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."antispam_form.php"; ?>
<div class="clearfix"></div>
<div id="ajax_response"></div>
</div>
</div>
</div>
<div class="clearfix"></div>