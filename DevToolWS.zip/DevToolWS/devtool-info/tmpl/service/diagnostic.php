<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">Website Diagnostic</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/diagnostic_large.png"/>
Web Site Diagnostic is a free online tool which allows you to quickly tests websites for dangerous web threats, malware or vulnerabilities.
Website will be scanned by the most popular antivirus programs such as Norton, AVG, McAfee.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."default_form.php"; ?>
<div class="clearfix"></div>
<div id="ajax_response"></div>
</div>
</div>
</div>
<div class="clearfix"></div>