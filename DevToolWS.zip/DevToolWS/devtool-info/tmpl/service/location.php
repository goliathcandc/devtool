<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">Domain Location</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/location_large.png"/>
Domain Location tools helsp you to identify domain's geographical location (city, country, region) using ip address lookup database.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."default_form.php"; ?>
<div class="clearfix"></div>
<div id="ajax_response"></div>
</div>
</div>
</div>
<div class="clearfix"></div>