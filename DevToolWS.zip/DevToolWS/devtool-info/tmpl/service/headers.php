<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">HTTP Headers</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/headers_large.png"/>
This tools allow you to inspect the HTTP headers that the web server returns when requesting a domain.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."headers_form.php"; ?>
<div class="clearfix"></div>
<div id="ajax_response"></div>
</div>
</div>
</div>
<div class="clearfix"></div>