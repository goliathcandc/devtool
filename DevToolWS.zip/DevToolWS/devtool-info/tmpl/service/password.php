<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">Password Generator</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/password_large.png"/>
The Online Password Generator allows you to create random passwords that are highly secure and extremely difficult to crack or guess due to an optional combination of different letters, numbers and symbols.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."password_form.php"; ?>
<div class="clearfix"></div>
</div>
</div>
</div>
<div class="clearfix"></div>