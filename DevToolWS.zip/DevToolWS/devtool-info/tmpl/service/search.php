<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">Indexed Pages</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/search_engine_large.png"/>
Use the free online Indexed Pages tool to check the indexing of Website in the major Search Engines
such as Google, Bing and Yahoo.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."default_form.php"; ?>
<div class="clearfix"></div>
<div id="ajax_response"></div>
</div>
</div>
</div>
<div class="clearfix"></div>