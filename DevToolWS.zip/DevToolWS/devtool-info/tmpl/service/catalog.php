<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">Directory Listing Checker</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/catalog_large.png"/>
Directory Listing Online Checker is a free tool which allows you to quickly find out wheter you are listed in the most popular directories such
as DMOZ (ODP), Yahoo, Alexa and Yandex.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."default_form.php"; ?>
<div class="clearfix"></div>
<div id="ajax_response"></div>
</div>
</div>
</div>
<div class="clearfix"></div>