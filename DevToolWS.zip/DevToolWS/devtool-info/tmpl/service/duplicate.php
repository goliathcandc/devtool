<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">Duplicate Remover</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/duplicate_large.png"/>
This free online Duplicate Remover is useful for webmasters to
remove repeating keywords from meta tags.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."duplicate_form.php"; ?>
<div class="clearfix"></div>
</div>
</div>
</div>
<div class="clearfix"></div>