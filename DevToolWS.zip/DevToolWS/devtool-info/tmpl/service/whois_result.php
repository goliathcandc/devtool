<h4><?= $domain ?> Whois Record</h4>
<pre>
<?= $data['Whois'] ?>
</pre>
