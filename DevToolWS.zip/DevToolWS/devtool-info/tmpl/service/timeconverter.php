<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">UNIX Time Converter</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/timeconverter_large.png"/>
This online tool converts Unix timestamp to human readable date/time.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."timeconverter_form.php"; ?>
<div class="clearfix"></div>
</div>
</div>
</div>
<div class="clearfix"></div>