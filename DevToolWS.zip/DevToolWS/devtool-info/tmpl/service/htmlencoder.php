<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">HTML Encoder</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/encoder_large.png"/>
Sometimes webmasters need to hide some text from search engines.
This online html encoder converts your text into Unicode or HexHTML string
which will be executed by browser on page load.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."htmlencoder_form.php"; ?>
<div class="clearfix"></div>
</div>
</div>
</div>
<div class="clearfix"></div>