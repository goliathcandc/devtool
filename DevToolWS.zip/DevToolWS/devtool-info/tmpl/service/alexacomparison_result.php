<h4>Alexa comparison graph: <?php echo implode(", ", $domains) ?></h4>
<br/>
<img src="<?php echo $alexa_img ?>" alt="Alexa comparison graph : <?php echo implode(", ", $domains) ?>" />
<br/><br/>