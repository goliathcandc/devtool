<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">Text Length Online</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/text_large.png"/>
Enter some text into the text area above and the table box will let you know how many characters, lines and word count are in the string.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."textlength_form.php"; ?>
<div class="clearfix"></div>
</div>
</div>
</div>
<div class="clearfix"></div>