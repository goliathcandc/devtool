<div class="dropdowns">
    <div class="block">
        <h1 class="block-header service-header">Backlinks</h1>
        <div class="block-wrap">
            <img class="service-thumb" src="static/img/backlinks.png" />
            Let’s find out, right now! Enter your domain and click the button to check how many backlinks your website has.
            <div class="clearfix"></div>
            <?php include ROOT."tmpl".DS."forms".DS."default_form.php"; ?>
            <div class="clearfix"></div>
            <div id="ajax_response"></div>
        </div>
    </div>
</div>
<div class="clearfix"></div>