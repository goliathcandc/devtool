<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">Meta Tags Generator</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/metatags_large.png"/>
Meta Tags Generator creates a well formated meta tags for your website with the entered values.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."metatags_form.php"; ?>
<div class="clearfix"></div>
<div id="ajax_response"></div>
</div>
</div>
</div>
<div class="clearfix"></div>