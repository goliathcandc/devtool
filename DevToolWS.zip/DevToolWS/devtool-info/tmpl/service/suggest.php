<div class="dropdowns">
    <div class="block">
        <h1 class="block-header service-header">Google Suggestion Tool</h1>
        <div class="block-wrap">
            <img class="service-thumb" src="static/img/suggest.png" />
            The Google Auto Suggest Keyword Tool is a free long tail keyword research tool that helps you find profitable keyword suggestions directly from Google search.
            <div class="clearfix"></div>
            <?php include ROOT."tmpl".DS."forms".DS."suggest_form.php"; ?>
            <div class="clearfix"></div>
            <div id="ajax_response"></div>
        </div>
    </div>
</div>
<div class="clearfix"></div>