<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">MD5/SHA-1 Hashing</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/hash_large.png"/>
MD5/SHA-1 Online Generator generates the hash of the string you input.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."hash_form.php"; ?>
<div class="clearfix"></div>
</div>
</div>
</div>
<div class="clearfix"></div>