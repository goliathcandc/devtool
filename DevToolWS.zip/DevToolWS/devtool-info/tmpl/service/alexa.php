<div class="dropdowns">
<div class="block">
<h1 class="block-header service-header">Alexa Statistics</h1>
<div class="block-wrap">
<img class="service-thumb" src="static/img/alexa_large.png"/>
Alexa Internet, Inc. is a California-based subsidiary company of Amazon.com which provides commercial web traffic data.
As of 2013, Alexa provides traffic data, global rankings and other information on 30 million websites, and claims 
that 6 million people visit its website monthly.
<div class="clearfix"></div>
<?php include ROOT."tmpl".DS."forms".DS."default_form.php"; ?>
<div class="clearfix"></div>
<div id="ajax_response"></div>
</div>
</div>
</div>
<div class="clearfix"></div>