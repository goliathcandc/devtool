<?php
return array(
	'special_chars' => '&rarr;&larr;&copy;&reg;&trade;',
	'symbols' => '!@#$%^*(){}[]?=',
	'letters' => 'abcdefghijklmnopqrstuvwxyz',
	'numbers' => '1234567890',
	'volves' => 'aeiou',
	'hyphen' => '-',
	'consonants' => 'bcdfghklmprstvxz',
);