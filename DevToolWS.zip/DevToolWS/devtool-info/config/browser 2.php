<?php
return array(
	'Google Bot' => 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
	'Google Mobile' => 'Googlebot-Mobile (compatible; Googlebot-Mobile/2.1; +http://www.google.com/bot.html)',
	'Yahoo Slurp' => 'Mozilla/5.0 (compatible; Yahoo! Slurp; http://help.yahoo.com/help/us/ysearch/slurp)',
	'MSN Bot' => 'msnbot/1.1 (+http://search.msn.com/msnbot.htm)',
	'Alexa Bot' => 'ia_archiver (+http://www.alexa.com/site/help/webmasters; crawler@alexa.com)',
	'My User Agent' => _v($_SERVER, 'HTTP_USER_AGENT', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.29 Safari/525.13'),
	'Empty' => '',
);