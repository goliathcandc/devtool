<?php
return array(
	"whois.nic.br" => "iso-8859-1",
	"whois.cira.ca" => "iso-8859-1",
	"whois.nic.cl" => "iso-8859-1",
	"whois.eenet.ee" => "iso-8859-1",
	"whois.ficora.fi" => "iso-8859-1",
	"whois.nic.fr" => "iso-8859-1",
	"whois.nic.hu" => "iso-8859-1",
	"whois.isnic.is" => "iso-8859-1",
	"whois.jprs.jp" => "iso-2022-jp",
	"whois.nic.ad.jp" => "iso-2022-jp",
	"whois.nic.or.kr" => "euc-kr",
	"whois.kr" => "euc-kr",
	"whois.dns.lu" => "iso-8859-1",
	"whois.norid.no" => "iso-8859-1",
	"whois.dns.pt" => "iso-8859-1",
	"whois.ua" => "koi8-u",
);


