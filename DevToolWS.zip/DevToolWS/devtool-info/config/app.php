<?php
return array (
	'admin_email' => 'sales@turnkey-shop.com',
	'rewrite' => true,
	'gmaps_api_key' => false,
);
