<?php
return array(
	'host'=>'localhost',
	'username'=>'devtool_databas',
	'passwd'=>'devtool_databas',
	'dbname'=>'devtool_databas',
);