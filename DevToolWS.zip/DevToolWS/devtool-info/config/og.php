<?php
return array(
	'title' => '',
	'description' => '',
	'image' => '',
	'site_name' => '',
);