<?php
return array(
	'404' => array(
		'title' => 'Page not found',
		'keywords' => '',
		'description' => '',
	),
	'alexa' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'antispam' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'catalog' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'diagnostic' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'dns' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'duplicate' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'hash' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'headers' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'htmlencoder' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'location' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'main' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'metatags' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'ogproperties' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'password' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'search' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'social' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'textlength' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'timeconverter' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
	'whois' => array(
		'title' => '',
		'keywords' => '',
		'description' => '',
	),
    // v 1.6
    'backlinks' => array(
        'title' => '',
        'keywords' => '',
        'description' => '',
    ),
    // v 1.6
    'suggest' => array(
        'title' => '',
        'keywords' => '',
        'description' => '',
    ),
    // v 1.6
    'alexacomparison' => array(
        'title' => '',
        'keywords' => '',
        'description' => '',
    ),
);