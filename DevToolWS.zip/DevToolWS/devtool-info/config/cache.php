<?php
return array(
	'alexa' => 60 * 60 * 4, // 4 hours
	'social' => 60 * 60 * 4, // 4 hours
	'catalog' => 60 * 60 * 24 * 7, // 7 days
	'diagnostic' => 60 * 60 * 24 * 1, // 1 day
	'search' => 60 * 60 * 24 * 1, // 1 day
	'location' => 60 * 60 * 24 * 1, // 1 day
	'whois' => 60 * 60 * 60 * 1, // 1 day
    'backlinks' => 60 * 60 * 60 * 1, // 1 day // v 1.6
);