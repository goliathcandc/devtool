<?php
return array(
	'alexa' => true, // Strongly recommended "true"
	'social' => true, // Strongly recommended "true"
	'catalog' => true, // Strongly recommended "true"
	'diagnostic' => true, // Strongly recommended "true"
	'search' => true, // Strongly recommended "true"
	'location' => true, // Strongly recommended "true"
	'whois' => true, // Strongly recommended "true"
	'dns' => false,
	'headers' => false,
	'antispam' => false,
    'alexacomparison' => true, // Strongly recommended "true" // v 1.6
    'backlinks' => true, // Strongly recommended "true" // v 1.6
    'suggest'=>false, // Better to set it "true" // v 1.6
);