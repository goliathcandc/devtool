<?php
return array(
    "com"=>"domain ={Domain}",
    "net"=>"domain ={Domain}",
    "de"=>"-T dn,ace {Domain}",
    "jp"=>"DOM {Domain}/e",
);