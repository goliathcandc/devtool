<?php
HtmlHead::setJs(array("ogproperties" => base_url().'static/js/ogproperties.js'));
include ROOT."tmpl".DS."service".DS."ogproperties.php";