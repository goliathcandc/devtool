<?php
HtmlHead::setJs(array("metatags" => base_url().'static/js/metatags.js'));
include ROOT."tmpl".DS."service".DS."metatags.php";