<?php
HtmlHead::setJs(array("encoder" => base_url().'static/js/duplicate.js'));
include ROOT."tmpl".DS."service".DS."duplicate.php";