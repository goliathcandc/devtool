<?php
HtmlHead::setJs(array("textlength" => base_url().'static/js/textlength.js'));
include ROOT."tmpl".DS."service".DS."textlength.php";