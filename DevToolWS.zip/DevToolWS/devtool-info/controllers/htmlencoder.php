<?php
HtmlHead::setJs(array("encoder" => base_url().'static/js/encoder.js'));
include ROOT."tmpl".DS."service".DS."htmlencoder.php";