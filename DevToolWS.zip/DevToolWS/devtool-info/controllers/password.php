<?php
HtmlHead::setJs(array("password" => base_url().'static/js/password.js'));
include ROOT."tmpl".DS."service".DS."password.php";