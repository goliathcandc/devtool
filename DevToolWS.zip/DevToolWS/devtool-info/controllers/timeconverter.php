<?php
HtmlHead::setJs(array("timeconverter" => base_url().'static/js/timeconverter.js'));
include ROOT."tmpl".DS."service".DS."timeconverter.php";