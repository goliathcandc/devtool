<?php

include ROOT."tmpl".DS."main.php";