<?php
include ROOT."tmpl".DS."404.php";