<?php
HtmlHead::setJs(array("hash" => base_url().'static/js/hash.js'));
include ROOT."tmpl".DS."service".DS."hash.php";